from animal import Animal

class snake(Animal):
    def __init__(self, nama, makanan, hidup, Berkembang_biak , bentuktubuh , ukuran):
        super().__init__(nama, makanan, hidup, Berkembang_biak)
        self.bentuktubuh = bentuktubuh
        self.ukuran = ukuran
        
    def info_snake(self):
        super().info_animal()
        print("bentuk tubuh\t\t:", self.bentuktubuh,"\nukuran\t\t\t:",self.ukuran)

kobra = snake("Ular Kobra", "Daging", "Dilaut/Didarat", "Bertelur","Ramping","1,5-4 meter")
print("## info snake ##")
kobra.info_snake()

python = snake("Ular Python", "Daging", "Dilaut/Didarat", "Bertelur","Ramping","1-6 meter")
print("## info snake ##")
python.info_snake()

viper = snake("Ular Viper", "Daging", "Dilaut/Didarat", "Bertelur", "Ramping", "0,5-1 meter")
print("## info snake ##")
viper.info_snake()